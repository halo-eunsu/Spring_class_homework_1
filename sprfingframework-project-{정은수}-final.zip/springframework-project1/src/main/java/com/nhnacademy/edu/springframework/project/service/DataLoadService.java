package com.nhnacademy.edu.springframework.project.service;


import org.springframework.stereotype.Component;


public interface DataLoadService {
    void loadAndMerge();
}
