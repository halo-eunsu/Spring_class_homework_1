package com.nhnacademy.edu.springframework.project.repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StudentsTest {

    @Test
    void load() {
    }

    @Test
    void findAll() {
    }

    @Test
    void merge() {
    }
}